import { useState, useEffect } from 'react'

const useFetchInfoPokemon = (apiUrl) => {
    const [infoPokemon, setInfoPokemon] = useState([])
    const [spritesPokemon, setSpritePokemon] = useState([])
    const [typePokemon, setTypePokemon] = useState([])
    const [abilityPokemon, setAbilityPokemon] = useState([])

    useEffect(() => {
        fetch(apiUrl)
            .then(resp => resp.json())
            .then((datos) => {
                setInfoPokemon(datos)
                setAbilityPokemon(datos.abilities)
                setSpritePokemon(datos.sprites)
                setTypePokemon(datos.types)
            })
    }, [apiUrl])

    return [infoPokemon, spritesPokemon, typePokemon, abilityPokemon]
}

export default useFetchInfoPokemon