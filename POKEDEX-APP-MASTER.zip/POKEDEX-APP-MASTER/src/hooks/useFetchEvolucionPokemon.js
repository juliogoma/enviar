import { useState, useEffect } from 'react'

const useFetchEvolucionPokemon = (apiUrl) => {
    const [infoEvolucionPokemon, setInfoEvolucionPokemon] = useState([])
    const [infoChainPokemon, setInfoChainPokemon] = useState([])
    const [infoEvolucionToPokemon, setInfoEvolucionToPokemon] = useState([])
    
    useEffect(() => {
        fetch(apiUrl)
            .then(resp => resp.json())
            .then((datos) => {
                setInfoEvolucionPokemon(datos)
                setInfoChainPokemon(datos.chain)
                setInfoEvolucionToPokemon(datos.chain.evolves_to)
            })
    }, [apiUrl])

    return [infoEvolucionPokemon, infoChainPokemon, infoEvolucionToPokemon]
}

export default useFetchEvolucionPokemon