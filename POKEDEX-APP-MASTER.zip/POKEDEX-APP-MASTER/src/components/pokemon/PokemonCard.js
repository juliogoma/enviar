import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import useFetchInfoPokemon from '../../hooks/useFetchInfoPokemon'
import useFetchEvolucionPokemon from '../../hooks/useFetchEvolucionPokemon'

const PokemonCard = ({
  name,
  url
}) => {
  const [infoPokemon, spritesPokemon, typePokemon] = useFetchInfoPokemon(url)

  const apiEvolUrl = `https://pokeapi.co/api/v2/evolution-chain/${infoPokemon.id}`
  const [infoEvolPokemon, infoChainPokemon, infoEvolToPokemon, abilityPokemon] = useFetchEvolucionPokemon(apiEvolUrl)

  const urlImgPokemon = spritesPokemon.front_default

  return (
    <div className="card" style={{ maxWidth: '100%' }}>
      <a href={`pokemon/${infoPokemon.id}`} ><img src={`${urlImgPokemon}`} className="card-img-top"
        alt={infoPokemon.name} /></a>
      <div className="card-body">
        <h5 className="card-title"><b>Nro.: </b>{infoPokemon.id}</h5>
        <p className="card-text" style={{ textTransform: 'capitalize' }}><b>Pokemón: </b>{name}</p>
        <p className="card-text"><b>Tipo: </b></p>
        <ul>
          {typePokemon.map((type) => (
            <li key={type.slot} style={{ textTransform: 'capitalize' }}>{type.type.name}</li>
          ))}
        </ul>
      </div>
    </div >
  )
}

export default PokemonCard
