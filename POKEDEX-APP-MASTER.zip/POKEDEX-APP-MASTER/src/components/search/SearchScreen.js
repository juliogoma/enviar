import React, { useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import queryString from 'query-string';

import useForm from '../../hooks/useForm'
import useFetchListPokemon from '../../hooks/useFetchListPokemon'

import PokemonCard from '../pokemon/PokemonCard'

const SearchScreen = ({ history }) => {
    const location = useLocation()
    const { q = '' } = queryString.parse(location.search)
    const [formValues, handleInput] = useForm({
        searText: q
    })
    const { searText } = formValues

    const [listPokemon] = useFetchListPokemon('https://pokeapi.co/api/v2/pokemon?limit=151')

    const handleSubmit = (e) => {
        e.preventDefault();
        history.push(`?q=${searText}`)
    }
    return (
        <div>
            <div className="row">
                {listPokemon.map(pokemon => (<PokemonCard key={pokemon.url} {...pokemon} />))}
            </div>
        </div>
    )
}

export default SearchScreen
