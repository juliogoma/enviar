import {Api} from '../api/Api'

export const getPokemonById = (id) => {
   
   return heroes.find( hero => hero.id === id)
}