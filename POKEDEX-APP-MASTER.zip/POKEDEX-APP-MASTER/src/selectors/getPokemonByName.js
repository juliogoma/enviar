import React from 'react'

export const getPokemonByName = ({listPokemon, name}) => {
    
    console.log(listPokemon)

    if (name === '') {
        return listPokemon
    }
  
    return ''
}