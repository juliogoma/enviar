import React from 'react';
import Api from './api/Api';

function App() {
  return (
   <Api />
  );
}

export default App;
